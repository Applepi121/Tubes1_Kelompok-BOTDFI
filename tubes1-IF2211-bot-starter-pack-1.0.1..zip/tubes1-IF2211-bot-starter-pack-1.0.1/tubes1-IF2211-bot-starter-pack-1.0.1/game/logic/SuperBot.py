import random
from typing import Optional, List, Tuple
import math

from game.logic.base import BaseLogic
from game.models import GameObject, Board, Position
from ..util import get_direction


class SuperBot(BaseLogic):
    def __init__(self):
        self.directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
        self.goal_position: Optional[Position] = None
        self.current_direction = 0
        self.target_diamond: Optional[GameObject] = None
        self.max_capacity = 5  # Maximum diamonds bot can carry
        self.visited_positions = set()  # Track visited positions
        self.exploration_count = 0
        
    def calculate_distance(self, pos1: Position, pos2: Position) -> float:
        """Calculate Euclidean distance between two positions"""
        return math.sqrt((pos1.x - pos2.x)**2 + (pos1.y - pos2.y)**2)
    
    def calculate_manhattan_distance(self, pos1: Position, pos2: Position) -> int:
        """Calculate Manhattan distance between two positions"""
        return abs(pos1.x - pos2.x) + abs(pos1.y - pos2.y)
    
    def get_diamond_efficiency(self, diamond: GameObject, bot_position: Position) -> float:
        """
        Calculate diamond efficiency using greedy criteria
        Efficiency = Points / (Distance + 1)
        Higher efficiency means better choice
        """
        distance = self.calculate_manhattan_distance(bot_position, diamond.position)
        
        # Avoid division by zero and give nearby items advantage
        adjusted_distance = distance + 1
        
        # Base efficiency: points per distance unit
        base_efficiency = diamond.properties.points / adjusted_distance
        
        # Bonus factors for greedy selection
        efficiency_bonus = 1.0
        
        # Bonus for diamond type (if available)
        if hasattr(diamond.properties, 'type'):
            if diamond.properties.type == 'red':
                efficiency_bonus *= 1.5  # Red diamonds prioritized
            elif diamond.properties.type == 'blue':
                efficiency_bonus *= 1.3
            elif diamond.properties.type == 'green':
                efficiency_bonus *= 1.1
        
        # Distance penalty for very far diamonds
        if distance > 15:
            efficiency_bonus *= 0.7
        elif distance > 10:
            efficiency_bonus *= 0.85
        
        # Bonus for high-value diamonds
        if diamond.properties.points >= 3:
            efficiency_bonus *= 1.2
        elif diamond.properties.points >= 2:
            efficiency_bonus *= 1.1
        
        return base_efficiency * efficiency_bonus
    
    def greedy_diamond_selection(self, bot: GameObject, board: Board) -> Optional[GameObject]:
        """
        Greedy algorithm to select the best diamond to collect next
        Always picks the diamond with highest efficiency score
        """
        current_position = bot.position
        available_diamonds = []
        
        # Get all diamonds on the board
        for game_object in board.game_objects:
            if game_object.type == "DiamondGameObject":
                available_diamonds.append(game_object)
        
        if not available_diamonds:
            return None
        
        # Calculate efficiency for each diamond
        diamond_scores = []
        for diamond in available_diamonds:
            efficiency = self.get_diamond_efficiency(diamond, current_position)
            diamond_scores.append({
                'diamond': diamond,
                'efficiency': efficiency,
                'distance': self.calculate_manhattan_distance(current_position, diamond.position),
                'points': diamond.properties.points
            })
        
        # Greedy choice: select diamond with highest efficiency
        best_diamond_data = max(diamond_scores, key=lambda x: x['efficiency'])
        
        return best_diamond_data['diamond']
    
    def should_return_to_base(self, bot: GameObject, board: Board) -> bool:
        """
        Greedy decision making for returning to base
        """
        current_diamonds = bot.properties.diamonds
        current_position = bot.position
        base_position = bot.properties.base
        
        # Always return if at maximum capacity
        if current_diamonds >= self.max_capacity:
            return True
        
        # Return if carrying 4 diamonds (greedy: secure the load)
        if current_diamonds >= 4:
            return True
        
        # Count remaining diamonds
        remaining_diamonds = sum(1 for obj in board.game_objects 
                               if obj.type == "DiamondGameObject")
        
        # Greedy: if very few diamonds left and we have some, secure them
        if remaining_diamonds <= 2 and current_diamonds >= 2:
            return True
        
        # Calculate distance to base
        base_distance = self.calculate_manhattan_distance(current_position, base_position)
        
        # Risk assessment: return if far from base with valuable load
        if current_diamonds >= 3 and base_distance > 12:
            return True
        
        # Greedy: if we have diamonds and no good targets nearby, return
        if current_diamonds >= 2:
            nearby_diamonds = [
                obj for obj in board.game_objects 
                if (obj.type == "DiamondGameObject" and 
                    self.calculate_manhattan_distance(current_position, obj.position) <= 5)
            ]
            
            if not nearby_diamonds:
                return True
        
        return False
    
    def get_best_exploration_direction(self, current_position: Position, board: Board) -> Tuple[int, int]:
        """
        Greedy exploration strategy
        Move towards areas with more diamonds or unexplored regions
        """
        direction_scores = {}
        
        # Score each possible direction
        for direction in self.directions:
            new_x = current_position.x + direction[0]
            new_y = current_position.y + direction[1]
            new_position = Position(new_x, new_y)
            
            score = 0
            
            # Avoid recently visited positions
            pos_key = (new_x, new_y)
            if pos_key not in self.visited_positions:
                score += 10
            
            # Look for diamonds in the direction (greedy: move toward resources)
            diamonds_in_direction = 0
            for game_object in board.game_objects:
                if game_object.type == "DiamondGameObject":
                    diamond_distance = self.calculate_manhattan_distance(new_position, game_object.position)
                    if diamond_distance <= 5:  # Diamonds within 5 units
                        diamonds_in_direction += 1
                        score += (6 - diamond_distance)  # Closer = better score
            
            direction_scores[direction] = score
        
        # Greedy choice: pick direction with highest score
        if direction_scores:
            best_direction = max(direction_scores.keys(), key=lambda d: direction_scores[d])
            return best_direction
        
        # Fallback to current direction
        return self.directions[self.current_direction]
    
    def update_exploration_state(self, position: Position):
        """Update exploration tracking"""
        pos_key = (position.x, position.y)
        self.visited_positions.add(pos_key)
        
        # Clean old positions to prevent memory bloat
        if len(self.visited_positions) > 50:
            # Remove some old positions (simple cleanup)
            positions_list = list(self.visited_positions)
            self.visited_positions = set(positions_list[-30:])
    
    def greedy_pathfinding(self, start: Position, target: Position) -> Tuple[int, int]:
        """
        Simple greedy pathfinding - always move toward target
        """
        delta_x = 0
        delta_y = 0
        
        # Greedy: prioritize the axis with larger difference
        x_diff = target.x - start.x
        y_diff = target.y - start.y
        
        if abs(x_diff) >= abs(y_diff):
            # Move in x direction first
            if x_diff > 0:
                delta_x = 1
            elif x_diff < 0:
                delta_x = -1
        else:
            # Move in y direction first
            if y_diff > 0:
                delta_y = 1
            elif y_diff < 0:
                delta_y = -1
        
        return delta_x, delta_y
    
    def next_move(self, board_bot: GameObject, board: Board):
        """
        Main greedy decision making for next move
        """
        current_position = board_bot.position
        
        # Update exploration state
        self.update_exploration_state(current_position)
        
        # Greedy decision: should we return to base?
        if self.should_return_to_base(board_bot, board):
            self.goal_position = board_bot.properties.base
            self.target_diamond = None
        else:
            # Greedy diamond selection
            best_diamond = self.greedy_diamond_selection(board_bot, board)
            
            if best_diamond:
                # Update target if we found a better diamond or don't have a target
                if (self.target_diamond is None or 
                    not any(obj.id == self.target_diamond.id for obj in board.game_objects) or
                    self.get_diamond_efficiency(best_diamond, current_position) > 
                    self.get_diamond_efficiency(self.target_diamond, current_position)):
                    
                    self.target_diamond = best_diamond
                    self.goal_position = best_diamond.position
            else:
                # No diamonds available
                self.target_diamond = None
                self.goal_position = None
        
        # Calculate movement based on greedy pathfinding
        if self.goal_position:
            # Use greedy pathfinding to move toward goal
            delta_x, delta_y = self.greedy_pathfinding(current_position, self.goal_position)
        else:
            # Greedy exploration when no specific target
            direction = self.get_best_exploration_direction(current_position, board)
            delta_x, delta_y = direction
            
            # Occasionally change direction for better exploration
            self.exploration_count += 1
            if self.exploration_count % 5 == 0:  # Every 5 moves
                self.current_direction = (self.current_direction + 1) % len(self.directions)
        
        return delta_x, delta_y
    
    def reset_target(self):
        """Reset current target when diamond is collected"""
        self.target_diamond = None
        self.goal_position = None
    
    def get_bot_status(self, bot: GameObject) -> dict:
        """Get current bot status for debugging"""
        return {
            'diamonds': bot.properties.diamonds,
            'position': (bot.position.x, bot.position.y),
            'target': (self.target_diamond.position.x, self.target_diamond.position.y) if self.target_diamond else None,
            'goal': (self.goal_position.x, self.goal_position.y) if self.goal_position else None,
            'visited_count': len(self.visited_positions)
        }


# Simplified version with even more aggressive greedy approach
class SimpleGreedyBot(BaseLogic):
    def __init__(self):
        self.directions = [(1, 0), (0, 1), (-1, 0), (0, -1)]
        self.current_direction = 0
        self.max_capacity = 5
    
    def calculate_manhattan_distance(self, pos1: Position, pos2: Position) -> int:
        """Calculate Manhattan distance between two positions"""
        return abs(pos1.x - pos2.x) + abs(pos1.y - pos2.y)
    
    def next_move(self, board_bot: GameObject, board: Board):
        """
        Ultra-simple greedy approach:
        1. If capacity full, go to base
        2. Otherwise, go to nearest diamond
        3. If no diamonds, explore randomly
        """
        current_position = board_bot.position
        
        # Simple greedy rule: return if full
        if board_bot.properties.diamonds >= self.max_capacity:
            base = board_bot.properties.base
            return self.move_toward(current_position, base)
        
        # Find nearest diamond (greedy choice)
        nearest_diamond = None
        min_distance = float('inf')
        
        for game_object in board.game_objects:
            if game_object.type == "DiamondGameObject":
                distance = self.calculate_manhattan_distance(current_position, game_object.position)
                if distance < min_distance:
                    min_distance = distance
                    nearest_diamond = game_object
        
        # Move toward nearest diamond
        if nearest_diamond:
            return self.move_toward(current_position, nearest_diamond.position)
        
        # No diamonds found, explore
        direction = self.directions[self.current_direction]
        if random.random() > 0.8:
            self.current_direction = (self.current_direction + 1) % len(self.directions)
        
        return direction
    
    def move_toward(self, start: Position, target: Position) -> Tuple[int, int]:
        """Simple greedy movement toward target"""
        if start.x < target.x:
            return (1, 0)
        elif start.x > target.x:
            return (-1, 0)
        elif start.y < target.y:
            return (0, 1)
        elif start.y > target.y:
            return (0, -1)
        else:
            return (0, 0)